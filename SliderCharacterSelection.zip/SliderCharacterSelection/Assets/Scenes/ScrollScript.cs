﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScrollScript : MonoBehaviour
{
    public List<Transform> images;
    public int defaultIndex = 5;
    private Vector2 _startingTouch;
    private bool _isSwiping;
    private bool _canSwipe;

    protected void Update()
    {
        if (!_canSwipe) return;
        if (Input.touchCount != 1) return;
        if (_isSwiping)
        {
            var diff = Input.GetTouch(0).position - _startingTouch;
            diff = new Vector2(diff.x / Screen.width, diff.y / Screen.width);

            if (diff.magnitude > 0.03f)
            {
                if (diff.x < 0)
                {
                    LeftClick();
                }
                else
                {
                    RightClick();
                }

                _isSwiping = false;
            }
        }


        if (Input.GetTouch(0).phase == TouchPhase.Began || Input.GetTouch(0).phase == TouchPhase.Stationary ||
            Input.GetTouch(0).phase == TouchPhase.Moved)
        {
            _startingTouch = Input.GetTouch(0).position;
            _isSwiping = true;
        }
        else if (Input.GetTouch(0).phase == TouchPhase.Ended)
        {
            _isSwiping = false;
        }
    }

    public void LeftClick()
    {
        defaultIndex--;
        images[0].SetSiblingIndex(images[images.Count - 1].GetSiblingIndex());
        var image = images[0];
        images.RemoveAt(0);
        images.Insert(images.Count, image);
    }


    public void RightClick()
    {
        defaultIndex++;
        images[images.Count - 1].SetSiblingIndex(images[0].GetSiblingIndex());
        var image = images[images.Count - 1];
        images.RemoveAt(images.Count - 1);
        images.Insert(0, image);
    }

    public void CanSwipe(bool value)
    {
        _canSwipe = value;
    }
}